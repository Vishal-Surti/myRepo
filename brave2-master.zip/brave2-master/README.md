Brave Theme.

Be Bold. Be Brave. Brave theme is a theme focussed around putting your product front and center. Featuring a mega menu for easy navigation, bold typography, and large product images Brave Theme gives you the best possible chance to capture your customers' attention.  
