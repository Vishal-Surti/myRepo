![Header](https://user-images.githubusercontent.com/40369168/118392057-1f632a00-b655-11eb-8079-ece17783ad35.png)

# Terminal portfolio
> I came up with my terminal portfolio in short after my [web portfolio](https://nitin30kumar.github.io/portfolio)  

![Black Eagle](https://user-images.githubusercontent.com/40369168/118392034-ffcc0180-b654-11eb-8254-631d13179ad4.png)

- Made with HTML, CSS and JavaScript  
- Visit my web portfolio [here](https://nitin30kumar.github.io/portfolio)

## Things needed to run this project
> Just need a browser to run it

___

__Check it's working [here](https://terminal-portfolio-nitin.netlify.app)__  
__You can star mark this project if you liked it__
